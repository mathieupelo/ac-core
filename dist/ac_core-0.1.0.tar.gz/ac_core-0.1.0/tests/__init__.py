"""
Test suite for AC Core library.
"""
